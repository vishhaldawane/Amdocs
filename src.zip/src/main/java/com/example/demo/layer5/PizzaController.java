package com.example.demo.layer5;
//whatever that doesnot depend upon your business logic, must be automated
//study, certification, 
//dish 
//khana

import java.util.ArrayList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


import com.example.demo.layer2.Pizza;

@RestController // REST
@RequestMapping("/pizzahut")
public class PizzaController {

	ArrayList<Pizza> listOfPizzas = new ArrayList<Pizza>(); //empty
	
	PizzaController() {
		Pizza pizza1 = new Pizza();
		pizza1.setId(1);
		pizza1.setCategory("Veg");
		pizza1.setDescription("Paneer");
		pizza1.setCost(300);
		pizza1.setSize("Small");
		
		
		Pizza pizza2 = new Pizza();
		pizza2.setId(2);
		pizza2.setCategory("Veg");
		pizza2.setDescription("Corn");
		pizza2.setCost(200);
		pizza2.setSize("Small");
		
		Pizza pizza3 = new Pizza();
		pizza3.setId(3);
		pizza3.setCategory("NonVeg");
		pizza3.setDescription("Chicken");
		pizza3.setCost(500);
		pizza3.setSize("Small");

		
		listOfPizzas.add(pizza1);
		listOfPizzas.add(pizza2);
		listOfPizzas.add(pizza3);
		
	}
	@GetMapping("/greet")
	public String sayHello() { // http://localhost:8080/pizzahut/greet
		return "<h1> Hello How are you </h1>";
	}
	
	@GetMapping("/fine")
	public String respond() { // http://localhost:8080/pizzahut/greet
		return "<h1> Im fine </h1>";
	}
	
	@GetMapping("/pizzas")
	public List<Pizza> showAllPizzas() { // http://localhost:8080/pizzahut/greet
		return listOfPizzas;
	}
	
}


// PizzaController pc = new PizzaController();
//pc.greet();